# Module 2 Group Assignment

CSCI 5117, Fall 2024, [assignment description](https://canvas.umn.edu/courses/460699/pages/project-2)

## App Info:

* Team Name: how-to-center-div
* App Name: BookBridge
* App Link: <https://TODO.com/>

### Students

* Benjamin Withey, withe096@umn.edu
* Dipan Bag, bag00003@umn.edu
* Cuong Ha , ha000065@umn.edu
* Jianing Wen, wen00112@umn.edu
* Ethan Huynh, huynh466@umn.edu


## Key Features

**Describe the most challenging features you implemented
(one sentence per bullet, maximum 4 bullets):**

* ...

Which (if any) device integration(s) does your app support?

* ...

Which (if any) progressive web app feature(s) does your app support?

* ...


## Mockup images

[Figma URL for Desktop version (Page 1 only, Page 2 is old design for Mobile)](https://www.figma.com/design/iwYBt3Nfl9xiiVLRZDDKY2/CSCI5117-Projec2?node-id=0-1&t=x1fC34fm0tXX9elf-1)

[Figma URL for Mobile Version](https://www.figma.com/design/4WArB1tZAPRyRYcQkVwP4o/Mobile-Version?node-id=0-1&m=dev&t=RfnWVihy5PMcmu3y-1)

![dekstop landing and profile](mockup_images/desktop_landing_profile.png)

![desktop home and library](mockup_images/desktop_home_library.png)

![desktop book detail and add book](mockup_images/desktop_book_detail_add_book.png)

![Mobile Login](mockup_images/Mobile_Login.png)

![Mobile Home](mockup_images/Mobile_Home.png)

![Mobile Profile](mockup_images/Mobile_Profile.png)

![Mobile Your Library](mockup_images/Mobile_Your_Library.png)

![Mobile Genre](mockup_images/Mobile_Genre.png)

![Mobile Specific Book](mockup_images/Mobile_Specific_Book.png)

![Mobile Add Book](mockup_images/Mobile_Add_Book.png)


## Testing Notes

**Is there anything special we need to know in order to effectively test your app? (optional):**

* ...



## Screenshots of Site (complete)

**[Add a screenshot of each key page](https://stackoverflow.com/questions/10189356/how-to-add-screenshot-to-readmes-in-github-repository)
along with a very brief caption:**

![](https://media.giphy.com/media/o0vwzuFwCGAFO/giphy.gif)



## External Dependencies

**Document integrations with 3rd Party code or services here.
Please do not document required libraries (e.g., React, Azure serverless functions, Azure nosql).**

* Library or service name: description of use
* ...

**If there's anything else you would like to disclose about how your project
relied on external code, expertise, or anything else, please disclose that
here:**

...
